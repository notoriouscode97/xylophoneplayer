//
//  ViewController.swift
//  Xylophone Player
//
//  Created by Apple on 11/1/17.
//  Copyright © 2017 Dusan Dimic. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate{
    
    
    var audioPlayer: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func notePressed(_ sender: UIButton) {
        playSound(soundPressed: sender.tag)
    }
    
    func playSound(soundPressed: Int) {
        let note = soundPressed
        let soundURL = Bundle.main.url(forResource: "note\(note)", withExtension: "wav")
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!)
        } catch let error as NSError {
            print(error)
        }
        audioPlayer.play()
    }
    
}



